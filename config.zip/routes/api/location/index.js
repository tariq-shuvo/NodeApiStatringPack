const getLocation = require('./get')

module.exports={
    getLocation
}