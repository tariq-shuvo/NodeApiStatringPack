const addRole = require('./add')
const removeRole = require('./remove')
const updateRole = require('./update')
const getRole = require('./get')

module.exports={
    addRole,
    removeRole,
    updateRole,
    getRole
}